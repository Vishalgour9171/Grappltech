// import React from 'react';
// import '../../styles//Features.scss';

// const Home = () => {
//     return (
//         <div classNameNameName="features">
//             <div classNameNameName="features__header">
//                 <h1>Features are more helpful to create creative shapes as well.</h1>
//                 <p>We are constantly rethinking the future by creating the next generation of products, brands and services from a hybrid perspective. The unthinkable today becomes inevitable.</p>
//             </div>
//             <div classNameNameName="features__content">
//                 <div classNameNameName="feature">
//                     <div classNameNameName="feature__icon feature__icon--branding"></div>
//                     <h2>Branding</h2>
//                     <p>Having these marketplace to your branded skilled team of designers and developers who embracement perfection.</p>
//                 </div>
//                 <div classNameNameName="feature">
//                     <div classNameNameName="feature__icon feature__icon--optimum"></div>
//                     <h2>Optimum</h2>
//                     <p>Brand identity design a the key to success whether you breath rebranding an existing business or creating a business.</p>
//                 </div>
//                 <div classNameNameName="feature">
//                     <div classNameNameName="feature__icon feature__icon--thinking"></div>
//                     <h2>Thinking</h2>
//                     <p>Creative typography plays the big role to pull off this trending more effectively with the thinking use a thicker point.</p>
//                 </div>
//                 <div classNameNameName="feature">
//                     <div classNameNameName="feature__icon feature__icon--execution"></div>
//                     <h2>Execution</h2>
//                     <p>Stricky with multiple shades of the colours. However, this type of alone can look awesome forever an online business.</p>
//                 </div>
//             </div>
//         </div>
//     );
// };

// export default Home;

// import React from "react";
// import "../../styles/demo.scss";
// function Home() {
//   return (
//     <div>
//       <section classNameNameName="p-0">
//         <div classNameNameName="container-fluid p-0">
//           <div classNameNameName="row g-0">
//             <div
//               classNameNameName="col-xl-6 col-lg-7 cover-background md-h-500px sm-h-400px md-mb-50px"

//             >
//               <div classNameNameName="position-absolute text-center blur-box right-30px bottom-30px sm-right-15px sm-bottom-15px pt-35px pb-35px ps-45px pe-45px sm-p-20px bg-white-transparent counter-style-04 d-flex align-items-center border-radius-6px">
//                 <h2
//                   classNameNameName="vertical-counter d-inline-flex alt-font text-dark-gray fw-700 mb-0 ls-minus-2px appear"
//                   data-text="+"
//                   data-to="353"
//                   style={{height: "55px"}}
//                 >
//                   <span classNameNameName="vertical-counter-number" data-to="3">
//                     3
//                   </span>
//                   <span classNameNameName="vertical-counter-number" data-to="5">
//                     5
//                   </span>
//                   <span classNameNameName="vertical-counter-number" data-to="3">
//                    3 +
//                   </span>
//                 </h2>
//                 <span classNameNameName="w-180px text-dark-gray text-start fw-500 lh-24 ms-15px sm-ms-10px">
//                   Very satisfied clients around the worldwide.
//                 </span>
//               </div>
//             </div>
//             <div classNameNameName="col-xxl-4 col-xl-5 col-lg-5 position-relative">
//               <div
//                 classNameNameName="contact-form-style-03 position-relative ps-15 pe-15 xxl-ps-10 xxl-pe-10 lg-ps-5 lg-pe-5 overflow-hidden last-paragraph-no-margin appear anime-child anime-complete"
//                 data-anime='{ "el": "childs", "translateY": [30, 0], "opacity": [0,1], "duration": 600, "delay":0, "staggervalue": 300, "easing": "easeOutQuad" }'
//               >
//                 <div classNameNameName="mb-10px">
//                   <span classNameNameName="w-25px h-1px d-inline-block bg-base-color me-5px align-middle"></span>
//                   <span classNameNameName="text-gradient-base-color fs-15 alt-font fw-700 ls-05px text-uppercase d-inline-block align-middle">
//                     Get in touch with us
//                   </span>
//                 </div>
//                 <h2 classNameNameName="text-dark-gray alt-font fw-600 w-90 xxl-w-100 ls-minus-2px">
//                   We'd love to hear from you!
//                 </h2>
//                 <form action="email-templates/contact-form.php" method="post">
//                   <div classNameNameName="position-relative form-group mb-20px">
//                     <span classNameNameName="form-icon">
//                       <i classNameNameName="bi bi-person icon-extra-medium text-dark-gray"></i>
//                     </span>
//                     <input
//                       classNameNameName="ps-0 border-radius-0px border-color-extra-medium-gray form-control required"
//                       type="text"
//                       name="name"
//                       placeholder="Your name*"
//                     />
//                   </div>
//                   <div classNameNameName="position-relative form-group mb-20px">
//                     <span classNameNameName="form-icon">
//                       <i classNameNameName="bi bi-envelope icon-extra-medium text-dark-gray"></i>
//                     </span>
//                     <input
//                       classNameNameName="ps-0 border-radius-0px border-bottom border-color-extra-medium-gray form-control required"
//                       type="email"
//                       name="email"
//                       placeholder="Your email address*"
//                     />
//                   </div>
//                   <div classNameNameName="position-relative form-group form-textarea mt-15px mb-0">
//                     <textarea
//                       classNameNameName="ps-0 border-radius-0px border-bottom border-color-extra-medium-gray form-control"
//                       name="comment"
//                       placeholder="Your message"
//                       rows="3"
//                     ></textarea>
//                     <span classNameNameName="form-icon">
//                       <i classNameNameName="bi bi-chat-square-dots icon-extra-medium text-dark-gray"></i>
//                     </span>
//                     <input type="hidden" name="redirect" value="" />
//                     <button
//                       classNameNameName="btn btn-medium btn-dark-gray btn-round-edge btn-box-shadow mb-20px mt-25px submit w-100 left-icon"
//                       type="submit"
//                     >
//                       <i classNameNameName="fa-regular fa-envelope"></i>Send message
//                     </button>
//                     <p classNameNameName="fs-14 lh-24 w-100 mb-0 text-center text-lg-start">
//                       We are committed to protecting your privacy. We will never
//                       collect information about you without your explicit
//                       consent.
//                     </p>
//                     <div classNameNameName="form-results mt-20px d-none"></div>
//                   </div>
//                 </form>
//               </div>
//             </div>
//           </div>
//         </div>
//       </section>
//     </div>
//   );
// }

// export default Home;
// import React, { useEffect, useState } from 'react';
// import '../../styles/demo.scss';
// import { Container, Row, Col } from 'react-bootstrap';
// import { FaReact, FaNodeJs, FaCss3Alt } from 'react-icons/fa';
// import slideImage from '../../assets/About/6.jpg'
// const sections = [
//   {
//     text: "Developers Digital",
//     image: "https://via.placeholder.com/400",
//     icons: [<FaReact key="react" classNameNameName="icon" />, <FaNodeJs key="node" classNameNameName="icon" />, <FaCss3Alt key="css" classNameNameName="icon" />]
//   },
//   {
//     text: "We are passionate designers",
//     image: "https://via.placeholder.com/400",
//     icons: [<FaReact key="react" classNameNameName="icon" />, <FaNodeJs key="node" classNameNameName="icon" />, <FaCss3Alt key="css" classNameNameName="icon" />]
//   },
//   {
//     text: "Contact Us",
//     image: "https://via.placeholder.com/400",
//     icons: [<FaReact key="react" classNameNameName="icon" />, <FaNodeJs key="node" classNameNameName="icon" />, <FaCss3Alt key="css" classNameNameName="icon" />]
//   },
//   // Add more sections as needed
// ];

// const App = () => {
//       const [currentSection, setCurrentSection] = useState(0);

//       useEffect(() => {
//         const intervalId = setInterval(() => {
//           setCurrentSection(prevSection => (prevSection + 1) % sections.length);
//         }, 10000000); // Change slide every 3 seconds

//         return () => clearInterval(intervalId); // Cleanup interval on component unmount
//       }, []);

//   return (
//     <Container fluid classNameNameName="vertical-scroll-container">
//       {sections.map((section, index) => (
//         <Row
//           classNameNameName="section"
//           key={index}
//           style={{ transform: `translateY(-${currentSection * 100}vh)` }}
//         >
//           <Col classNameNameName="section-content">
//             <div
//               classNameNameName="section-image"
//               style={{ backgroundImage: `url(${section.image})` }}
//             ></div>
//             <div classNameNameName="section-text">
//               <h2>{section.text}</h2>
//               <div classNameNameName="section-icons">
//                 {section.icons}
//               </div>
//             </div>
//           </Col>
//         </Row>
//       ))}
//       <div classNameNameName="nav-icons">
//         {sections.map((_, index) => (
//           <div
//             key={index}
//             classNameNameName={`nav-icon ${index === currentSection ? 'active' : ''}`}
//             onClick={() => setCurrentSection(index)}
//           ></div>
//         ))}
//       </div>

//     </Container>
//   );
// }

// export default App;

// import React from "react";
// import '../../styles/demo.scss'
// import intropage from '../../assets/intropage/1.png'
// import Arrow16 from '../../assets/intropage/16.png'
// import creative from '../../assets/intropage/Creative.png'
// import creative1 from '../../assets/intropage/Creative1.png'
// import express from '../../assets/intropage/express.png'
// import innovate from '../../assets/intropage/innovate.png'
// function Home() {
//   return (
//     <div>
//       <section classNameNameName="intro_portfolio__hero-area intro_portfolio_section">
//         <div classNameNameName="container">
//           <div classNameNameName="row">
//             <div classNameNameName="col-xxl-12">
//               <div classNameNameName="intro-portfolio__hero">
//               <div classNameNameName="margin">
//                 <h1 classNameNameName="title shape-circle">Full stack</h1>
//                 <h2 classNameNameName="title text-stroke">Web &amp; Mobile</h2>
//                 <h2 classNameNameName="title">developer</h2>
//                 </div>
//                 <div classNameNameName="btn-wrapper">
//                   <a href="portfolio.html" classNameNameName="wc-btn-dark">
//                     View all work
//                   </a>
//                 </div>
//                 <img
//                   src={intropage}
//                   alt="Personal Portfolio"
//                   classNameNameName="pp-thumb"
//                   style={{translate:" none", rotate: "none", scale: "none", transform: "translate(-60px, 0px) scale(1.15, 1.15)"}}
//                 />
//               </div>
//             </div>
//           </div>
//         </div>
//       </section>
//       <section classNameNameName="intro-portfolio-section intro-portfolio__about ">
//                   <div classNameNameName="container">
//                     <div classNameNameName="row">
//                       <div classNameNameName="col-xxl-8 col-xxl-8 col-lg-8">
//                         <div classNameNameName="intro-portfolio__about-left">
//                           <h2 classNameNameName="sec-title">
//                             I craft wonderful <span>digital experiences</span> for brands
//                           </h2>
//                           <img src={Arrow16} alt="Shape" />
//                         </div>
//                       </div>
//                       <div classNameNameName="col-xxl-4 col-xl-4 col-lg-4">
//                         <div classNameNameName="sec-text">
//                           <p>Based in Washington, DC, I work with experts from the Center for Strategic and
//                             International
//                             Studies (CSIS) to help them communicate their research more effectively on the web.
//                             Together we
//                             make websites, data visualizations, and long-forms that strengthen their networks and
//                             engage new
//                             audiences with thoughtful content and design strategies.</p>
//                           <a href="about.html" classNameNameName="wc-btn-dark">Explore Me</a>
//                         </div>
//                       </div>
//                     </div>

//                     <div classNameNameName="about-row">
//                       <div classNameNameName="row">
//                         <div classNameNameName="col-xxl-3 col-xl-3 col-lg-3 col-md-4">
//                           <div classNameNameName="brand-title-wrap">
//                             <h3 classNameNameName="brand-title">worked with global largest brands</h3>
//                           </div>
//                         </div>
//                         <div classNameNameName="col-xxl-9 col-xl-9 col-lg-9 col-md-8">
//                           <div classNameNameName="brand-list">
//                             <div classNameNameName="brand-Logo">
//                               <img src={creative} alt="Brand Logo"/>
//                             </div>
//                             <div classNameNameName="brand-Logo">
//                               <img src={creative1} alt="Brand Logo"/>
//                             </div>
//                             <div classNameNameName="brand-Logo">
//                               <img src={express} alt="Brand Logo"/>
//                             </div>
//                             <div classNameNameName="brand-Logo" >
//                               <img src={innovate} alt="Brand Logo"/>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                 </section>

//                 <section classNameNameName="intro-portfolio-section intro-portfolio__service pt-140 pb-140">
//                   <div classNameNameName="container">
//                     <div classNameNameName="row">
//                       <div classNameNameName="col-xxl-5 col-xl-5 col-lg-6 col-md-6">
//                         <h2 classNameNameName="sec-title"> I MAKE
//                           THE Service
//                           BETTER.</h2>
//                       </div>
//                       <div classNameNameName="col-xxl-7 col-xl-7 col-lg-6 col-md-6">
//                         <div classNameNameName="sec-text">
//                           <p>Static and dynamic secure code review can prevent a 0day before your product is even
//                             released. We
//                             can integrate with your dev environment</p>
//                         </div>
//                       </div>
//                     </div>
//                     <div classNameNameName="intro-portfolio__service-list">
//                       <div classNameNameName="row">
//                         <div classNameNameName="col-xxl-4 col-xl-4 col-lg-4 col-md-4">
//                           <div classNameNameName="intro-portfolio__service-item">
//                             <a href="service-details.html">
//                               <h3 classNameNameName="ps-title">Frontend <br/> Developemnt</h3>
//                               <ul>
//                                 <li>+ WordPress</li>
//                                 <li>+ Python</li>
//                                 <li>+ PHP &amp; Laravel</li>
//                               </ul>
//                             </a>
//                           </div>
//                         </div>
//                         <div classNameNameName="col-xxl-4 col-xl-4 col-lg-4 col-md-4">
//                           <div classNameNameName="intro-portfolio__service-item">
//                             <a href="service-details.html">
//                               <h3 classNameNameName="ps-title">Backend<br/> Developemnt</h3>
//                               <ul>
//                                 <li>+ WordPress</li>
//                                 <li>+ Python</li>
//                                 <li>+ PHP &amp; Laravel</li>
//                               </ul>
//                             </a>
//                           </div>
//                         </div>
//                         <div classNameNameName="col-xxl-4 col-xl-4 col-lg-4 col-md-4">
//                           <div classNameNameName="intro-portfolio__service-item">
//                             <a href="service-details.html">
//                               <h3 classNameNameName="ps-title">Android<br/> Developemnt</h3>
//                               <ul>
//                                 <li>+ WordPress</li>
//                                 <li>+ Python</li>
//                                 <li>+ PHP &amp; Laravel</li>
//                               </ul>
//                             </a>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                     <div classNameNameName="row">
//                       <div classNameNameName="col-xxl-12">
//                         <div classNameNameName="ps-btn">
//                           <a href="contact.html">Call me to get more extra service <strong>call now</strong></a>
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                 </section>

//     </div>
//   );
// }

// export default Home;

// import React, { useState } from 'react';
// import '../../styles/demo.scss';

// function Home() {
//   const [activeIndex, setActiveIndex] = useState(null);

//   const handleClick = (index) => {
//     setActiveIndex(index === activeIndex ? null : index);
//   };

//   return (
//     <div classNameName="accordion">
//       <ul>
//         {[
//           {
//             title: 'SIGHTSEEING',
//             subtitle: 'Explore Scottsdale & Beyond',
//             imageUrl: 'http://res.cloudinary.com/simpleview/image/upload/v1473537250/clients/scottsdale/Waterfront_Canal_overhead_shot_night_1__7abd0528-2310-45cb-8ade-ef538cc53251.jpg'
//           },
//           {
//             title: 'Dining',
//             subtitle: 'Eat Like a Local',
//             imageUrl: 'http://res.cloudinary.com/simpleview/image/upload/v1528125519/clients/scottsdale/Halie_Sutton_Scottsdale_Undertow_9481_f9f68275-db93-4d1a-9163-13ea1c3bad67.jpg'
//           },
//           {
//             title: 'OUTDOORS',
//             subtitle: 'Seek Adventure',
//             imageUrl: 'http://res.cloudinary.com/simpleview/image/upload/v1524516076/clients/scottsdale/Riding_near_Granite_Mountain_76f3d366-4dc0-487c-bd71-cae1615633a2.jpg'
//           },
//           {
//             title: 'Accommodations',
//             subtitle: 'Stay a While',
//             imageUrl: 'http://res.cloudinary.com/simpleview/image/upload/v1524866182/clients/scottsdale/087_3_2249_jpeg_4efee80a-c4c4-4672-b81f-072e7714082f.jpg'
//           },
//           {
//             title: 'Golf',
//             subtitle: 'Tee it Up',
//             imageUrl: 'http://res.cloudinary.com/simpleview/image/upload/v1525217553/clients/scottsdale/Kierland_Golf_Club_5d0e148d-69ef-4943-8540-6ebe0a4cd216.jpg'
//           },
//           {
//             title: 'Nightlife',
//             subtitle: 'Play After Dark',
//             imageUrl: 'http://res.cloudinary.com/simpleview/image/upload/v1525446371/clients/scottsdale/Talking_Stick_Sunset1_Cordwell_f5ba762b-f42a-4bf7-bf7d-bad5a841bf07.jpg'
//           },
//           {
//             title: 'ART + CULTURE',
//             subtitle: 'Find Your Muse',
//             imageUrl: 'http://res.cloudinary.com/simpleview/image/upload/v1523399533/clients/scottsdale/AFAR_SCOTTSDALE_CORDWELL_062017_17_66a9fb48-f82f-4f1d-9403-2762f78e5f1b.jpg'
//           },
//           {/* {
//             title: 'Spa & wellness',
//             subtitle: 'Relax and Unwind',
//             imageUrl: 'http://res.cloudinary.com/simpleview/image/upload/v1512147648/clients/scottsdale/TSR_Spa_5ad5c4b7-2134-40d7-b8cf-ca5ba83c67d9.jpg'
//           } */}
//         ].map((item, index) => (
//           <li key={index} onClick={() => handleClick(index)} classNameName={activeIndex === index ? 'active' : ''}>
//             <div>
//               <a href="#" classNameName="sliderLink">
//                 <h2>{item.title}</h2>
//                 <p>{item.subtitle}</p>
//               </a>
//             </div>
//             <style jsx>{`
//               .accordion ul li:nth-child(${index + 1}) {
//                 background-image: url(${item.imageUrl});
//                 background-position: 50% 30%;
//               }
//             `}</style>
//           </li>
//         ))}
//       </ul>
//     </div>
//   );
// }

// export default Home;
// src/CircleAnimation.js


// import React, { useState } from 'react';
// import '../../styles/demo.scss'; // Assuming you save the CSS code in a file named Lesson.css

// const Home = () => {
//   const [activeIndex, setActiveIndex] = useState(0);

//   const handleClick = (index) => {
//     setActiveIndex(index);
//   };

//   return (
//     <div className="lesson">
//       <h2>How To Make Scroll To Top Button</h2>
//       <p>
//         <a href="https://www.youtube.com/watch?v=t4e_RBpkB8c">Lesson On Youtube</a>
//       </p>
//       <hr />
//       <section>
//         {[...Array(5)].map((_, index) => (
//           <React.Fragment key={index}>
//             <div className="item" onClick={() => handleClick(index)}>
//               Item
//             </div>
//             <div className={`info ${activeIndex === index ? 'active' : ''}`}>
//               Info
//             </div>
//           </React.Fragment>
//         ))}
//       </section>
//     </div>
//   );
// };

// export default Home;


import React, { useState } from 'react';
import '../../styles/demo.scss';

const HoverCircle = () => {
    const [hoverStyle, setHoverStyle] = useState({
        clipPath: 'circle(0% at 0% 0%)',
        x: '0%',
        y: '0%'
    });

    const handleMouseMove = (e) => {
        const rect = e.target.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const percentX = (x / rect.width) * 100;
        const percentY = (y / rect.height) * 100;

        setHoverStyle({
            clipPath: `circle(150% at ${100 - percentX}% ${100 - percentY}%)`,
            x: `${percentX}%`,
            y: `${percentY}%`
        });
    };

    const handleMouseLeave = () => {
        setHoverStyle({
            clipPath: 'circle(0% at 0% 0%)',
            x: '0%',
            y: '0%'
        });
    };

    return (
        <div className="circle-box" onMouseMove={handleMouseMove} onMouseLeave={handleMouseLeave}>
            <div
                className="color-overlay"
                style={{
                    clipPath: hoverStyle.clipPath,
                    '--x': hoverStyle.x,
                    '--y': hoverStyle.y
                }}
            ></div>
        </div>
    );
};

export default HoverCircle;


