// reusable js function that needs in many components will come here
