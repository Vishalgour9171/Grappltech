import noConnection from "./noconnection.svg";
import noData from "./nodata.svg";
import pageNotFound from "./pageNotFound.svg";
import profile from "./profile.svg";

export { noConnection, noData, pageNotFound, profile };
